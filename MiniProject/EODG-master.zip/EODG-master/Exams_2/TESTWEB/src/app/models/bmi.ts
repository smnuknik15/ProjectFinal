export interface BMI {
    WEIGHT:string,
    HEIGHT:string,
    PERSON_CODE:string,
    RESULT:string
}
