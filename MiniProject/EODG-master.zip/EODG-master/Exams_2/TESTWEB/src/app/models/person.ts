export interface Person {
    PERSION_NUMBER:string,
    INITIAL_CODE:string,
    NAME:string,
    LASTNAME:string,
    GENDER:string,
    AGE:string
}
